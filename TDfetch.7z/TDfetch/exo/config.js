export const ENDPOINT = 'http://localhost:3000/voitures';
export const ENDPOINTUSER = 'https://jsonplaceholder.typicode.com/users';